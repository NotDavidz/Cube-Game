for event in pygame.event.get():
    if event.type == pygame.MOUSEBUTTONDOWN:
        buttons = pygame.mouse.get_pressed()
        if buttons[0]:
            if scene == 50:
                if posX > 440 and posX < 490 and posY > 450 and posY < 500:
                    level_reset(False) 
                    scene = 1
                if posX > 800 and posX < 900 and posY > 450 and posY < 500: 
                    scene = 2
            if scene == 40:
                if posX > 590 and posX < 690 and posY > 450 and posY < 500:    
                    level_reset(False)
                    scene = 1
                    
#Requires Bound to be 4 digit array          

                    
def exit_btn(bound):
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            buttons = pygame.mouse.get_pressed()
            if buttons[0]: